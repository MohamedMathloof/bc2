import { Product, Category } from './types';

export const categories: Category[] = [
  {
    id: 1,
    name: 'Furniture',
    slug: 'furniture',
    description: 'Sustainable bamboo and cane furniture',
    imageUrl: 'https://github.com/MohamedMathloof/bcproducts/blob/main/s2.png?raw=true'
  },
  {
    id: 2,
    name: 'Miniatures',
    slug: 'miniatures',
    description: 'Decorative miniature creations',
    imageUrl: 'https://github.com/MohamedMathloof/bcproducts/blob/main/mv.png?raw=true'
  },
  {
    id: 3,
    name: 'Kitchen Items',
    slug: 'kitchen',
    description: 'Eco-friendly kitchen accessories',
    imageUrl: 'https://github.com/MohamedMathloof/bcproducts/blob/main/ediyappam.jpeg?raw=true'
  },
  {
    id: 4,
    name: 'Baby Products',
    slug: 'baby-products',
    description: 'Bamboo products for children',
    imageUrl:  'https://github.com/MohamedMathloof/bcproducts/blob/main/bc1.jpeg?raw=true'
  }
];

export const allProducts: Product[] = [
  // Furniture
  {
    id: 1,
    name: ' Traditional Sofa Set',
    category: 'Furniture',
    categorySlug: 'furniture',
    price: 18000,
    imageUrl: 'https://github.com/MohamedMathloof/bcproducts/blob/main/s2.png?raw=true',
    shortDescription: 'Elegant 3-seater bamboo sofa with cushions',
    description: 'This elegant bamboo sofa set combines comfort with sustainable materials. The frame is crafted from quality bamboo poles, providing both durability and a natural aesthetic. Comes with comfortable cushions in a neutral color that complements the bamboo\'s natural tone.',
    featured: true
  },
  {
    id: 2,
    name: 'Elegant Sofa Set',
    category: 'Furniture',
    categorySlug: 'furniture',
    price: 15000,
    imageUrl: 'https://github.com/MohamedMathloof/bcproducts/blob/main/s3.png?raw=true',
    shortDescription: 'Contemporary 2-seater sofa with cane backrest',
    featured: false
  },
  {
    id: 3,
    name: 'Raidan Swing',
    category: 'Furniture',
    categorySlug: 'furniture',
    price: 5000,
    imageUrl: 'https://github.com/MohamedMathloof/bcproducts/blob/main/sw4-removebg-preview.jpg?raw=true',
    shortDescription: 'Comfortable outdoor swing for gardens and patios',
    featured: true
  },
  {
    id: 4,
    name: 'Elegant Strong Swing',
    category: 'Furniture',
    categorySlug: 'furniture',
    price: 3800,
    imageUrl: 'https://github.com/MohamedMathloof/bcproducts/blob/main/sw2-removebg-preview%20(1).jpg?raw=true',
    shortDescription: 'Elegant hanging swing for indoor spaces',
    featured: false
  },
  {
    id: 5,
    name: 'Deluxe Modern Chair',
    category: 'Furniture',
    categorySlug: 'furniture',
    price: 5200,
    imageUrl: 'https://github.com/MohamedMathloof/bcproducts/blob/main/ch2-removebg-preview.jpg?raw=true',
    shortDescription: 'Premium quality bamboo swing with cushions',
    featured: false
  },
  
  // Miniatures
  {
    id: 6,
    name: 'Hand-held fan(visiri)',
    category: 'Miniatures',
    categorySlug: 'miniatures',
    price: 100,
    imageUrl: 'https://github.com/MohamedMathloof/bcproducts/blob/main/mv.png?raw=true?raw=true',
    shortDescription: 'Intricately designed bamboo elephant figurine',
    featured: true
  },
  {
    id: 7,
    name: 'Basket',
    category: 'Miniatures',
    categorySlug: 'miniatures',
    price: 200,
    imageUrl: 'https://github.com/MohamedMathloof/bcproducts/blob/main/bas1.jpeg?raw=true',
    shortDescription: 'Detailed miniature house made from cane',
    featured: false
  },
  
  // Kitchen Items
  {
    id: 8,
    name: 'Bamboo Idiyappam Plate  set(2)',
    category: 'Kitchen Items',
    categorySlug: 'kitchen',
    price: 100 ,
    imageUrl: 'https://github.com/MohamedMathloof/bcproducts/blob/main/ediyappam.jpeg?raw=true',
    shortDescription: 'Traditional bamboo plate for serving idiyappam',
    featured: true
  },
  {
    id: 9,
    name: 'Rice Basket',
    category: 'Kitchen Items',
    categorySlug: 'kitchen',
    price: 680,
    imageUrl: 'https://github.com/MohamedMathloof/bcproducts/blob/main/kk.jpeg?raw=true',
    shortDescription: 'Handwoven cane basket for fruits and vegetables and rice storage ',
    featured: false
  },
  
  // Baby Products
  {
    id: 10,
    name: 'Baby Cane Swing',
    category: 'Baby Products',
    categorySlug: 'baby-products',
    price: 1800,
    imageUrl: 'https://github.com/MohamedMathloof/bcproducts/blob/main/brw2-removebg-preview.jpg?raw=true',
    shortDescription: 'Safe and comfortable bamboo swing for infants',
    featured: true
  },
  {
    id: 11,
    name: 'Cane Baby Chair',
    category: 'Baby Products',
    categorySlug: 'baby-products',
    price: 700,
    imageUrl: 'https://github.com/MohamedMathloof/bcproducts/blob/main/bc1.jpeg?raw=true',
    shortDescription: 'Ergonomic bamboo high chair for toddlers',
    featured: false
  },
  {
    id: 12,
    name: 'Baby Racking Chair',
    category: 'Baby Products',
    categorySlug: 'baby-products',
    price: 1000,
    imageUrl: 'https://github.com/MohamedMathloof/bcproducts/blob/main/brc.jpg?raw=true',
    shortDescription: 'Gentle bamboo rocking chair for babies',
    featured: false
  }
];

export const featuredProducts = allProducts.filter(product => product.featured);