// Product Types
export interface Product {
  id: number;
  name: string;
  category: string;
  categorySlug: string;
  price: number;
  imageUrl: string;
  shortDescription: string;
  description?: string;
  featured?: boolean;
}

export interface CartItem extends Product {
  quantity: number;
}

// User Types
export interface Address {
  street: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
}

export interface User {
  id: number;
  name: string;
  email: string;
  phone: string;
  address: Address;
}

// Order Types
export type PaymentMethod = 'COD' | 'CARD' | 'UPI';

export type OrderStatus = 'PENDING' | 'PROCESSING' | 'SHIPPED' | 'DELIVERED' | 'CANCELLED';

export interface OrderItem {
  productId: number;
  productName: string;
  price: number;
  quantity: number;
  imageUrl: string;
}

export interface Order {
  id: string;
  userId: number;
  items: OrderItem[];
  total: number;
  shipping: number;
  status: OrderStatus;
  paymentMethod: PaymentMethod;
  createdAt: string;
  address: Address;
}

// Category Type
export interface Category {
  id: number;
  name: string;
  slug: string;
  description: string;
  imageUrl: string;
}