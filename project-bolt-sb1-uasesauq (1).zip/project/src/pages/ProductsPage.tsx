import React, { useState, useEffect } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';
import ProductGrid from '../components/products/ProductGrid';
import { allProducts, categories } from '../utils/data';
import { Filter, SortDesc, SortAsc, X } from 'lucide-react';

const ProductsPage = () => {
  const { category } = useParams<{ category?: string }>();
  const [searchParams] = useSearchParams();
  const searchQuery = searchParams.get('search') || '';
  
  const [filteredProducts, setFilteredProducts] = useState(allProducts);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 10000]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>(category ? [category] : []);
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc' | null>(null);
  const [filtersOpen, setFiltersOpen] = useState(false);
  
  // Find the category name if a slug is provided
  const categoryName = category 
    ? categories.find(c => c.slug === category)?.name || 'Products'
    : searchQuery 
    ? `Search Results for "${searchQuery}"`
    : 'All Products';

  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = `${categoryName} - B & C Products`;
    
    // Reset selected categories when category param changes
    if (category) {
      setSelectedCategories([category]);
    } else {
      setSelectedCategories([]);
    }
  }, [category, categoryName]);

  useEffect(() => {
    let filtered = [...allProducts];
    
    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(product => 
        product.name.toLowerCase().includes(query) ||
        product.category.toLowerCase().includes(query) ||
        product.shortDescription.toLowerCase().includes(query)
      );
    }
    
    // Filter by category
    if (selectedCategories.length > 0) {
      filtered = filtered.filter(product => 
        selectedCategories.includes(product.categorySlug)
      );
    }
    
    // Filter by price range
    filtered = filtered.filter(product => 
      product.price >= priceRange[0] && product.price <= priceRange[1]
    );
    
    // Sort products
    if (sortOrder === 'asc') {
      filtered.sort((a, b) => a.price - b.price);
    } else if (sortOrder === 'desc') {
      filtered.sort((a, b) => b.price - a.price);
    }
    
    setFilteredProducts(filtered);
  }, [selectedCategories, priceRange, sortOrder, searchQuery]);

  const handleCategoryChange = (categorySlug: string) => {
    setSelectedCategories(prev => {
      if (prev.includes(categorySlug)) {
        return prev.filter(c => c !== categorySlug);
      } else {
        return [...prev, categorySlug];
      }
    });
  };

  const handlePriceChange = (value: number, index: 0 | 1) => {
    setPriceRange(prev => {
      const newRange = [...prev] as [number, number];
      newRange[index] = value;
      return newRange;
    });
  };

  const clearFilters = () => {
    setSelectedCategories(category ? [category] : []);
    setPriceRange([0, 10000]);
    setSortOrder(null);
  };

  const toggleSort = () => {
    if (sortOrder === null) setSortOrder('asc');
    else if (sortOrder === 'asc') setSortOrder('desc');
    else setSortOrder(null);
  };

  return (
    <div className="bg-gray-50 min-h-screen">
      {/* Hero Banner */}
      <div className="bg-gradient-to-r from-green-700 to-amber-600 text-white py-12">
        <div className="container-custom">
          <h1 
            className="text-3xl md:text-4xl font-bold mb-2"
            data-aos="fade-up"
          >
            {categoryName}
          </h1>
          <p 
            className="text-lg text-white/90 max-w-2xl"
            data-aos="fade-up"
            data-aos-delay="100"
          >
            {searchQuery 
              ? `Found ${filteredProducts.length} products matching your search`
              : 'Discover our beautiful collection of handcrafted bamboo and cane products, made with care and attention to detail.'}
          </p>
        </div>
      </div>
      
      <div className="container-custom py-12">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Filters - Desktop */}
          <div className="hidden lg:block space-y-8">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-semibold">Filters</h3>
                <button 
                  onClick={clearFilters}
                  className="text-sm text-green-700 hover:text-green-800"
                >
                  Clear All
                </button>
              </div>
              
              {/* Categories */}
              <div className="mb-6">
                <h4 className="font-medium mb-2">Categories</h4>
                <div className="space-y-2">
                  {categories.map(cat => (
                    <label key={cat.id} className="flex items-center">
                      <input 
                        type="checkbox"
                        checked={selectedCategories.includes(cat.slug)}
                        onChange={() => handleCategoryChange(cat.slug)}
                        className="mr-2 h-4 w-4 rounded border-gray-300 text-green-600 focus:ring-green-500"
                      />
                      <span className="text-gray-700">{cat.name}</span>
                    </label>
                  ))}
                </div>
              </div>
              
              {/* Price Range */}
              <div>
                <h4 className="font-medium mb-2">Price Range</h4>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>₹{priceRange[0]}</span>
                    <span>₹{priceRange[1]}</span>
                  </div>
                  <input 
                    type="range"
                    min="0"
                    max="10000"
                    step="500"
                    value={priceRange[0]}
                    onChange={(e) => handlePriceChange(Number(e.target.value), 0)}
                    className="w-full"
                  />
                  <input 
                    type="range"
                    min="0"
                    max="10000"
                    step="500"
                    value={priceRange[1]}
                    onChange={(e) => handlePriceChange(Number(e.target.value), 1)}
                    className="w-full"
                  />
                </div>
              </div>
            </div>
          </div>
          
          {/* Products Grid */}
          <div className="lg:col-span-3">
            {/* Mobile Filters Button and Sorting */}
            <div className="flex items-center justify-between mb-6">
              <button 
                onClick={() => setFiltersOpen(true)}
                className="lg:hidden flex items-center px-4 py-2 bg-white border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                <Filter className="w-4 h-4 mr-2" />
                Filters
              </button>
              
              <button 
                onClick={toggleSort}
                className="flex items-center px-4 py-2 bg-white border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                {sortOrder === 'asc' && <SortAsc className="w-4 h-4 mr-2" />}
                {sortOrder === 'desc' && <SortDesc className="w-4 h-4 mr-2" />}
                {sortOrder === null && <span className="mr-2">Sort</span>}
                Price {sortOrder === 'asc' ? '(Low to High)' : sortOrder === 'desc' ? '(High to Low)' : ''}
              </button>
            </div>
            
            {/* Results Count */}
            <p className="text-gray-600 mb-6">
              Showing {filteredProducts.length} {filteredProducts.length === 1 ? 'product' : 'products'}
            </p>
            
            {/* Product Grid */}
            {filteredProducts.length > 0 ? (
              <ProductGrid products={filteredProducts} />
            ) : (
              <div className="text-center py-16">
                <h3 className="text-xl font-semibold mb-2">No products found</h3>
                <p className="text-gray-600 mb-4">Try adjusting your filters or search criteria.</p>
                <button 
                  onClick={clearFilters}
                  className="btn-primary"
                >
                  Clear Filters
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Mobile Filters Drawer */}
      <div className={`fixed inset-0 bg-black bg-opacity-50 z-50 transition-opacity duration-300 ${filtersOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
        <div className={`fixed inset-y-0 left-0 max-w-xs w-full bg-white shadow-xl transform transition-transform duration-300 ease-in-out ${filtersOpen ? 'translate-x-0' : '-translate-x-full'}`}>
          <div className="flex items-center justify-between p-4 border-b">
            <h3 className="text-lg font-medium">Filters</h3>
            <button 
              onClick={() => setFiltersOpen(false)}
              className="p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          
          <div className="p-4 overflow-y-auto">
            {/* Categories */}
            <div className="mb-6">
              <h4 className="font-medium mb-2">Categories</h4>
              <div className="space-y-2">
                {categories.map(cat => (
                  <label key={cat.id} className="flex items-center">
                    <input 
                      type="checkbox"
                      checked={selectedCategories.includes(cat.slug)}
                      onChange={() => handleCategoryChange(cat.slug)}
                      className="mr-2 h-4 w-4 rounded border-gray-300 text-green-600 focus:ring-green-500"
                    />
                    <span className="text-gray-700">{cat.name}</span>
                  </label>
                ))}
              </div>
            </div>
            
            {/* Price Range */}
            <div>
              <h4 className="font-medium mb-2">Price Range</h4>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span>₹{priceRange[0]}</span>
                  <span>₹{priceRange[1]}</span>
                </div>
                <input 
                  type="range"
                  min="0"
                  max="10000"
                  step="500"
                  value={priceRange[0]}
                  onChange={(e) => handlePriceChange(Number(e.target.value), 0)}
                  className="w-full"
                />
                <input 
                  type="range"
                  min="0"
                  max="10000"
                  step="500"
                  value={priceRange[1]}
                  onChange={(e) => handlePriceChange(Number(e.target.value), 1)}
                  className="w-full"
                />
              </div>
            </div>
            
            <div className="mt-8 flex space-x-4">
              <button 
                onClick={clearFilters}
                className="flex-1 py-2 px-4 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                Clear All
              </button>
              <button 
                onClick={() => setFiltersOpen(false)}
                className="flex-1 py-2 px-4 bg-green-700 text-white rounded-md text-sm font-medium hover:bg-green-800"
              >
                Apply
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductsPage;