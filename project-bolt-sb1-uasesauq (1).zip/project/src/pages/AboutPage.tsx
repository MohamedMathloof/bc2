import React, { useEffect } from 'react';
import { Leaf, Award, Users, Phone, Mail, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';

const AboutPage = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = 'About Us - B & C Products';
  }, []);

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-green-700 to-amber-600 text-white py-24">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto text-center">
            <h1 
              className="text-4xl md:text-5xl font-bold mb-6"
              data-aos="fade-up"
            >
              Our Story
            </h1>
            <p 
              className="text-xl text-white/90"
              data-aos="fade-up"
              data-aos-delay="100"
            >
              Dedicated to bringing the beauty of bamboo and cane into your homes through sustainable craftsmanship
            </p>
          </div>
        </div>
      </div>
      
      {/* Mission Section */}
      <section className="py-16">
        <div className="container-custom">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div data-aos="fade-right">
              <h2 className="text-3xl font-bold mb-6">Our Mission</h2>
              <p className="text-gray-700 mb-4">
                At B & C Products, we are committed to preserving traditional bamboo and cane craftsmanship while creating modern, functional products that enhance your living spaces.
              </p>
              <p className="text-gray-700 mb-4">
                We believe in sustainable practices that respect our environment. By choosing natural materials like bamboo and cane, we promote eco-friendly alternatives to synthetic products.
              </p>
              <p className="text-gray-700 mb-6">
                Our skilled artisans combine generations of knowledge with innovative design to create products that are both beautiful and practical, bringing a touch of nature into your home.
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <Leaf className="w-10 h-10 text-green-600" />
                  </div>
                  <div className="ml-4">
                    <h3 className="text-lg font-semibold mb-1">Sustainability</h3>
                    <p className="text-gray-600">Eco-friendly materials and practices</p>
                  </div>
                </div>
                <div className="flex">
                  <div className="flex-shrink-0">
                    <Award className="w-10 h-10 text-green-600" />
                  </div>
                  <div className="ml-4">
                    <h3 className="text-lg font-semibold mb-1">Quality</h3>
                    <p className="text-gray-600">Meticulous attention to detail</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="relative product-3d-container" data-aos="fade-left">
              <div className="product-3d">
                <img 
                  src="https://images.pexels.com/photos/4210340/pexels-photo-4210340.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                  alt="Artisans working on bamboo products" 
                  className="rounded-lg shadow-xl"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Our Story Timeline */}
      <section className="py-16 bg-gray-50">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4" data-aos="fade-up">Our Journey</h2>
            <p className="text-gray-600 max-w-3xl mx-auto" data-aos="fade-up" data-aos-delay="100">
              From humble beginnings to becoming a trusted name in bamboo and cane products
            </p>
          </div>
          
          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-0.5 bg-green-200"></div>
            
            {/* Timeline Items */}
            <div className="space-y-12">
              {[
                {
                  year: '2010',
                  title: 'Our Beginning',
                  description: 'Started as a small family workshop with a passion for bamboo crafts.',
                  image: 'https://images.pexels.com/photos/4207783/pexels-photo-4207783.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
                },
                {
                  year: '2015',
                  title: 'Growing Our Craft',
                  description: 'Expanded our range to include furniture and home decor items.',
                  image: 'https://images.pexels.com/photos/4207791/pexels-photo-4207791.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
                },
                {
                  year: '2020',
                  title: 'Going Digital',
                  description: 'Launched our online store to reach customers across India.',
                  image: 'https://images.pexels.com/photos/8088451/pexels-photo-8088451.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
                },
                {
                  year: '2023',
                  title: 'Today',
                  description: 'Continuing to grow while maintaining our commitment to quality and sustainability.',
                  image: 'https://images.pexels.com/photos/4207770/pexels-photo-4207770.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
                }
              ].map((item, index) => (
                <div key={index} className="relative" data-aos={index % 2 === 0 ? "fade-right" : "fade-left"}>
                  <div className={`flex items-center ${index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'}`}>
                    {/* Timeline Dot */}
                    <div className="absolute left-1/2 transform -translate-x-1/2 -translate-y-4 w-8 h-8 rounded-full bg-green-600 border-4 border-white z-10 flex items-center justify-center">
                      <span className="text-xs font-bold text-white">{item.year}</span>
                    </div>
                    
                    {/* Content */}
                    <div className={`w-1/2 ${index % 2 === 0 ? 'pr-12 text-right' : 'pl-12'}`}>
                      <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                      <p className="text-gray-600">{item.description}</p>
                    </div>
                    
                    {/* Image */}
                    <div className={`w-1/2 ${index % 2 === 0 ? 'pl-12' : 'pr-12'}`}>
                      <img 
                        src={item.image} 
                        alt={item.title}
                        className="rounded-lg shadow-md w-full h-48 object-cover"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
      
      {/* Our Team */}
      <section className="py-16">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4" data-aos="fade-up">Meet Our Team</h2>
            <p className="text-gray-600 max-w-3xl mx-auto" data-aos="fade-up" data-aos-delay="100">
              Skilled artisans and dedicated professionals who bring our vision to life
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                name: 'Mohamed Mathloof',
                role: 'Founder & Lead Artisan',
                image: 'https://i.pravatar.cc/300?img=13',
                bio: 'With over 15 years of experience in bamboo crafting, Mohamed leads our design and production processes.'
              },
              {
                name: 'Priya Sharma',
                role: 'Design Specialist',
                image: 'https://i.pravatar.cc/300?img=28',
                bio: 'Priya combines traditional patterns with modern aesthetics to create unique designs for our products.'
              },
              {
                name: 'Raj Kumar',
                role: 'Master Craftsman',
                image: 'https://i.pravatar.cc/300?img=11',
                bio: 'Raj has been working with bamboo since childhood and brings unparalleled expertise to our workshop.'
              }
            ].map((member, index) => (
              <div 
                key={index} 
                className="bg-white rounded-lg overflow-hidden shadow-md transition-transform hover:-translate-y-2 duration-300"
                data-aos="fade-up"
                data-aos-delay={index * 100}
              >
                <img 
                  src={member.image} 
                  alt={member.name}
                  className="w-full h-64 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-1">{member.name}</h3>
                  <p className="text-green-600 font-medium mb-3">{member.role}</p>
                  <p className="text-gray-600">{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Contact Section */}
      <section className="py-16 bg-gray-50">
        <div className="container-custom">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div data-aos="fade-right">
              <h2 className="text-3xl font-bold mb-6">Get In Touch</h2>
              <p className="text-gray-700 mb-8">
                We'd love to hear from you! Whether you have questions about our products, custom orders, or wholesale inquiries, our team is here to help.
              </p>
              
              <div className="space-y-6">
                <div className="flex items-start">
                  <Phone className="w-6 h-6 text-green-600 mr-4 mt-1" />
                  <div>
                    <h3 className="font-semibold mb-1">Call or WhatsApp</h3>
                    <a href="tel:+919566315769" className="text-gray-700 hover:text-green-700">+91 9566315769</a>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <Mail className="w-6 h-6 text-green-600 mr-4 mt-1" />
                  <div>
                    <h3 className="font-semibold mb-1">Email</h3>
                    <a href="mailto:mohamedmathloof8@gmail.com" className="text-gray-700 hover:text-green-700">mohamedmathloof8@gmail.com</a>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <MapPin className="w-6 h-6 text-green-600 mr-4 mt-1" />
                  <div>
                    <h3 className="font-semibold mb-1">Location</h3>
                    <p className="text-gray-700">
                      B & C Products Workshop,<br />
                      Tamil Nadu, India
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            <div data-aos="fade-left">
              <form className="bg-white p-8 rounded-lg shadow-md">
                <div className="mb-6">
                  <label htmlFor="name" className="block text-gray-700 font-medium mb-2">Your Name</label>
                  <input 
                    type="text" 
                    id="name" 
                    className="input-field"
                    placeholder="John Doe"
                  />
                </div>
                
                <div className="mb-6">
                  <label htmlFor="email" className="block text-gray-700 font-medium mb-2">Email Address</label>
                  <input 
                    type="email" 
                    id="email" 
                    className="input-field"
                    placeholder="john@example.com"
                  />
                </div>
                
                <div className="mb-6">
                  <label htmlFor="message" className="block text-gray-700 font-medium mb-2">Message</label>
                  <textarea 
                    id="message" 
                    rows={4} 
                    className="input-field"
                    placeholder="How can we help you?"
                  ></textarea>
                </div>
                
                <button type="submit" className="btn-primary w-full py-3">
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 bg-green-700 text-white">
        <div className="container-custom text-center">
          <h2 className="text-3xl font-bold mb-6" data-aos="fade-up">Ready to Experience Natural Elegance?</h2>
          <p className="text-xl text-white/90 mb-8 max-w-3xl mx-auto" data-aos="fade-up" data-aos-delay="100">
            Browse our collection of handcrafted bamboo and cane products and bring sustainable beauty into your home.
          </p>
          <Link 
            to="/products" 
            className="inline-block bg-white text-green-700 hover:bg-gray-100 font-bold py-3 px-8 rounded-md transition-colors"
            data-aos="fade-up" 
            data-aos-delay="200"
          >
            Shop Now
          </Link>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;