import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser } from '../contexts/UserContext';
import { User, Order } from '../utils/types';
import { Package, Settings, LogOut, User as UserIcon, MapPin, ShoppingBag, Heart } from 'lucide-react';

const ProfilePage = () => {
  const { user, isLoggedIn, logout, updateUserProfile } = useUser();
  const navigate = useNavigate();
  
  const [activeTab, setActiveTab] = useState('profile');
  const [profileData, setProfileData] = useState<Partial<User>>({
    name: user?.name || '',
    email: user?.email || '',
    phone: user?.phone || '',
    address: user?.address || {
      street: '',
      city: '',
      state: '',
      zipCode: '',
      country: 'India'
    }
  });
  
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  
  // Sample orders data (in a real app, this would come from an API)
  const [orders, setOrders] = useState<Order[]>([
    {
      id: 'ORD-1234',
      userId: user?.id || 0,
      items: [
        {
          productId: 1,
          productName: 'Bamboo Sofa Set',
          price: 8500,
          quantity: 1,
          imageUrl: 'https://images.pexels.com/photos/4210804/pexels-photo-4210804.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
        },
        {
          productId: 8,
          productName: 'Bamboo Idiyappam Plate',
          price: 450,
          quantity: 2,
          imageUrl: 'https://images.pexels.com/photos/4226866/pexels-photo-4226866.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
        }
      ],
      total: 9400,
      shipping: 0,
      status: 'DELIVERED',
      paymentMethod: 'CARD',
      createdAt: '2023-11-15T10:30:00Z',
      address: {
        street: '123 Main St',
        city: 'Bangalore',
        state: 'Karnataka',
        zipCode: '560001',
        country: 'India'
      }
    },
    {
      id: 'ORD-5678',
      userId: user?.id || 0,
      items: [
        {
          productId: 3,
          productName: 'Bamboo Garden Swing',
          price: 4500,
          quantity: 1,
          imageUrl: 'https://images.pexels.com/photos/6301168/pexels-photo-6301168.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
        }
      ],
      total: 4750,
      shipping: 250,
      status: 'SHIPPED',
      paymentMethod: 'UPI',
      createdAt: '2023-12-20T14:15:00Z',
      address: {
        street: '123 Main St',
        city: 'Bangalore',
        state: 'Karnataka',
        zipCode: '560001',
        country: 'India'
      }
    }
  ]);
  
  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = 'My Account - B & C Products';
    
    // If not logged in, redirect to home
    if (!isLoggedIn) {
      navigate('/');
    }
  }, [isLoggedIn, navigate]);
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    
    if (name.includes('.')) {
      // Handle nested address fields
      const [parent, child] = name.split('.');
      setProfileData(prev => ({
        ...prev,
        [parent]: {
          ...prev[parent as keyof typeof prev],
          [child]: value
        }
      }));
    } else {
      setProfileData(prev => ({ ...prev, [name]: value }));
    }
  };
  
  const handleSaveProfile = async () => {
    if (!isEditing) {
      setIsEditing(true);
      return;
    }
    
    setIsSaving(true);
    
    try {
      await updateUserProfile(profileData);
      setIsEditing(false);
    } catch (error) {
      console.error('Failed to update profile:', error);
    } finally {
      setIsSaving(false);
    }
  };
  
  const handleLogout = () => {
    logout();
    navigate('/');
  };
  
  if (!isLoggedIn) {
    return null; // Will redirect via useEffect
  }
  
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container-custom">
        <h1 className="text-3xl font-bold mb-10" data-aos="fade-up">My Account</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Sidebar Navigation */}
          <div className="md:col-span-1" data-aos="fade-right">
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="p-6 bg-gradient-to-r from-green-700 to-amber-600 text-white">
                <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center mb-3 mx-auto">
                  <UserIcon className="w-8 h-8 text-green-700" />
                </div>
                <h2 className="text-lg font-semibold text-center">{user?.name}</h2>
                <p className="text-sm text-center text-white/80 truncate">{user?.email}</p>
              </div>
              
              <nav className="p-4">
                <ul className="space-y-1">
                  <li>
                    <button
                      onClick={() => setActiveTab('profile')}
                      className={`w-full flex items-center p-3 rounded-md transition-colors ${
                        activeTab === 'profile' 
                          ? 'bg-green-50 text-green-700' 
                          : 'hover:bg-gray-50'
                      }`}
                    >
                      <UserIcon className="w-5 h-5 mr-3" />
                      <span>My Profile</span>
                    </button>
                  </li>
                  <li>
                    <button
                      onClick={() => setActiveTab('orders')}
                      className={`w-full flex items-center p-3 rounded-md transition-colors ${
                        activeTab === 'orders' 
                          ? 'bg-green-50 text-green-700' 
                          : 'hover:bg-gray-50'
                      }`}
                    >
                      <Package className="w-5 h-5 mr-3" />
                      <span>My Orders</span>
                    </button>
                  </li>
                  <li>
                    <button
                      onClick={() => setActiveTab('addresses')}
                      className={`w-full flex items-center p-3 rounded-md transition-colors ${
                        activeTab === 'addresses' 
                          ? 'bg-green-50 text-green-700' 
                          : 'hover:bg-gray-50'
                      }`}
                    >
                      <MapPin className="w-5 h-5 mr-3" />
                      <span>Addresses</span>
                    </button>
                  </li>
                  <li>
                    <button
                      onClick={() => setActiveTab('wishlist')}
                      className={`w-full flex items-center p-3 rounded-md transition-colors ${
                        activeTab === 'wishlist' 
                          ? 'bg-green-50 text-green-700' 
                          : 'hover:bg-gray-50'
                      }`}
                    >
                      <Heart className="w-5 h-5 mr-3" />
                      <span>Wishlist</span>
                    </button>
                  </li>
                  <li>
                    <button
                      onClick={() => setActiveTab('settings')}
                      className={`w-full flex items-center p-3 rounded-md transition-colors ${
                        activeTab === 'settings' 
                          ? 'bg-green-50 text-green-700' 
                          : 'hover:bg-gray-50'
                      }`}
                    >
                      <Settings className="w-5 h-5 mr-3" />
                      <span>Settings</span>
                    </button>
                  </li>
                  <li>
                    <button
                      onClick={handleLogout}
                      className="w-full flex items-center p-3 text-red-500 hover:bg-red-50 rounded-md transition-colors"
                    >
                      <LogOut className="w-5 h-5 mr-3" />
                      <span>Logout</span>
                    </button>
                  </li>
                </ul>
              </nav>
            </div>
          </div>
          
          {/* Main Content Area */}
          <div className="md:col-span-3" data-aos="fade-left">
            {/* Profile Tab */}
            {activeTab === 'profile' && (
              <div className="bg-white rounded-lg shadow-sm p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-semibold">Personal Information</h2>
                  <button
                    onClick={handleSaveProfile}
                    className={`${
                      isEditing
                        ? 'bg-green-600 hover:bg-green-700 text-white'
                        : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
                    } px-4 py-2 rounded-md transition-colors flex items-center`}
                  >
                    {isSaving ? (
                      <>
                        <svg className="animate-spin -ml-1 mr-2 h-4 w-4" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Saving...
                      </>
                    ) : isEditing ? (
                      'Save Changes'
                    ) : (
                      'Edit Profile'
                    )}
                  </button>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="name" className="block text-gray-600 text-sm font-medium mb-2">
                      Full Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={profileData.name}
                      onChange={handleInputChange}
                      disabled={!isEditing}
                      className="input-field"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-gray-600 text-sm font-medium mb-2">
                      Email Address
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={profileData.email}
                      onChange={handleInputChange}
                      disabled={!isEditing}
                      className="input-field"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="phone" className="block text-gray-600 text-sm font-medium mb-2">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={profileData.phone}
                      onChange={handleInputChange}
                      disabled={!isEditing}
                      className="input-field"
                    />
                  </div>
                </div>
                
                <div className="mt-8 mb-4">
                  <h3 className="font-medium text-lg mb-4">Default Address</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="address.street" className="block text-gray-600 text-sm font-medium mb-2">
                        Street Address
                      </label>
                      <input
                        type="text"
                        id="address.street"
                        name="address.street"
                        value={profileData.address?.street}
                        onChange={handleInputChange}
                        disabled={!isEditing}
                        className="input-field"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="address.city" className="block text-gray-600 text-sm font-medium mb-2">
                        City
                      </label>
                      <input
                        type="text"
                        id="address.city"
                        name="address.city"
                        value={profileData.address?.city}
                        onChange={handleInputChange}
                        disabled={!isEditing}
                        className="input-field"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="address.state" className="block text-gray-600 text-sm font-medium mb-2">
                        State
                      </label>
                      <input
                        type="text"
                        id="address.state"
                        name="address.state"
                        value={profileData.address?.state}
                        onChange={handleInputChange}
                        disabled={!isEditing}
                        className="input-field"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="address.zipCode" className="block text-gray-600 text-sm font-medium mb-2">
                        ZIP / Postal Code
                      </label>
                      <input
                        type="text"
                        id="address.zipCode"
                        name="address.zipCode"
                        value={profileData.address?.zipCode}
                        onChange={handleInputChange}
                        disabled={!isEditing}
                        className="input-field"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="address.country" className="block text-gray-600 text-sm font-medium mb-2">
                        Country
                      </label>
                      <input
                        type="text"
                        id="address.country"
                        name="address.country"
                        value={profileData.address?.country}
                        onChange={handleInputChange}
                        disabled={true}
                        className="input-field bg-gray-50"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {/* Orders Tab */}
            {activeTab === 'orders' && (
              <div className="bg-white rounded-lg shadow-sm overflow-hidden">
                <div className="p-6 border-b border-gray-200">
                  <h2 className="text-xl font-semibold">My Orders</h2>
                </div>
                
                {orders.length > 0 ? (
                  <div className="divide-y divide-gray-200">
                    {orders.map((order) => (
                      <div key={order.id} className="p-6">
                        <div className="flex flex-col md:flex-row justify-between mb-4">
                          <div>
                            <h3 className="text-lg font-medium">{order.id}</h3>
                            <p className="text-sm text-gray-500">
                              Placed on {new Date(order.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                          <div className="mt-2 md:mt-0">
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                              order.status === 'DELIVERED' ? 'bg-green-100 text-green-800' :
                              order.status === 'SHIPPED' ? 'bg-blue-100 text-blue-800' :
                              order.status === 'PROCESSING' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-gray-100 text-gray-800'
                            }`}>
                              {order.status}
                            </span>
                          </div>
                        </div>
                        
                        <div className="space-y-4 mb-4">
                          {order.items.map((item) => (
                            <div key={item.productId} className="flex">
                              <div className="flex-shrink-0 w-16 h-16 bg-gray-100 rounded-md overflow-hidden">
                                <img 
                                  src={item.imageUrl} 
                                  alt={item.productName} 
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <div className="ml-4 flex-1">
                                <h4 className="text-sm font-medium">{item.productName}</h4>
                                <p className="mt-1 text-sm text-gray-500">Qty: {item.quantity}</p>
                                <p className="mt-1 text-sm font-medium">₹{item.price.toLocaleString()}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                        
                        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pt-4 border-t border-gray-200">
                          <div>
                            <p className="text-sm font-medium">Total: ₹{order.total.toLocaleString()}</p>
                            <p className="text-sm text-gray-500">
                              Payment: {
                                order.paymentMethod === 'COD' ? 'Cash on Delivery' :
                                order.paymentMethod === 'CARD' ? 'Card' : 'UPI'
                              }
                            </p>
                          </div>
                          <button className="mt-3 sm:mt-0 text-sm text-green-700 hover:text-green-800 font-medium">
                            View Details
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-6 text-center">
                    <div className="w-16 h-16 mx-auto bg-gray-100 rounded-full flex items-center justify-center mb-4">
                      <ShoppingBag className="w-8 h-8 text-gray-400" />
                    </div>
                    <h3 className="text-lg font-medium mb-2">No Orders Yet</h3>
                    <p className="text-gray-500 mb-4">
                      You haven't placed any orders yet.
                    </p>
                    <button 
                      onClick={() => navigate('/products')}
                      className="btn-primary"
                    >
                      Start Shopping
                    </button>
                  </div>
                )}
              </div>
            )}
            
            {/* Other tabs would be implemented similarly */}
            {activeTab === 'addresses' && (
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h2 className="text-xl font-semibold mb-6">My Addresses</h2>
                <p className="text-gray-600">Manage your shipping and billing addresses.</p>
                {/* Address management would go here */}
              </div>
            )}
            
            {activeTab === 'wishlist' && (
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h2 className="text-xl font-semibold mb-6">My Wishlist</h2>
                <p className="text-gray-600">View and manage your wishlist items.</p>
                {/* Wishlist would go here */}
              </div>
            )}
            
            {activeTab === 'settings' && (
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h2 className="text-xl font-semibold mb-6">Account Settings</h2>
                <p className="text-gray-600">Manage your account settings and preferences.</p>
                {/* Settings would go here */}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;