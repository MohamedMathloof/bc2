import React, { useEffect } from 'react';
import Hero from '../components/home/Hero';
import FeaturedCategories from '../components/home/FeaturedCategories';
import ProductGrid from '../components/products/ProductGrid';
import { featuredProducts } from '../utils/data';
import { Leaf, Award, Truck, Shield } from 'lucide-react';

const HomePage = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = 'B & C Products - Bamboo & Cane Creations';
  }, []);

  return (
    <>
      <Hero />
      
      <FeaturedCategories />
      
      {/* Featured Products Section */}
      <ProductGrid 
        products={featuredProducts}
        title="Featured Products"
        subtitle="Explore our most popular bamboo and cane creations"
      />
      
      {/* Benefits Section */}
      <section className="py-16 bg-green-50">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="section-title" data-aos="fade-up">Why Choose Our Products?</h2>
            <p className="section-subtitle" data-aos="fade-up" data-aos-delay="100">
              We combine traditional craftsmanship with modern design principles
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: <Leaf className="w-10 h-10 text-green-600" />,
                title: 'Eco-Friendly',
                description: 'Our products are made from sustainably sourced bamboo and cane materials.'
              },
              {
                icon: <Award className="w-10 h-10 text-green-600" />,
                title: 'Quality Craftsmanship',
                description: 'Each piece is carefully handcrafted by skilled artisans with attention to detail.'
              },
              {
                icon: <Truck className="w-10 h-10 text-green-600" />,
                title: 'Fast Delivery',
                description: 'We offer quick and reliable shipping throughout India.'
              },
              {
                icon: <Shield className="w-10 h-10 text-green-600" />,
                title: 'Durability Guaranteed',
                description: 'Our products are built to last with proper care and maintenance.'
              }
            ].map((benefit, index) => (
              <div 
                key={index}
                className="bg-white p-6 rounded-lg shadow-md text-center"
                data-aos="fade-up"
                data-aos-delay={index * 100}
              >
                <div className="flex justify-center mb-4">
                  {benefit.icon}
                </div>
                <h3 className="text-xl font-semibold mb-3">{benefit.title}</h3>
                <p className="text-gray-600">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Testimonial Section */}
      <section className="py-16 bg-white">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="section-title" data-aos="fade-up">What Our Customers Say</h2>
            <p className="section-subtitle" data-aos="fade-up" data-aos-delay="100">
              Don't just take our word for it - hear from our satisfied customers
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: 'Priya Sharma',
                avatar: 'https://i.pravatar.cc/150?img=32',
                text: 'The bamboo sofa set I purchased is not only beautiful but extremely comfortable. It brings a natural warmth to my living room that I love!',
                rating: 5
              },
              {
                name: 'Raj Patel',
                avatar: 'https://i.pravatar.cc/150?img=12',
                text: 'The craftsmanship on the baby chair is exceptional. My daughter loves it, and I appreciate that it\'s made from sustainable materials.',
                rating: 5
              },
              {
                name: 'Anita Desai',
                avatar: 'https://i.pravatar.cc/150?img=26',
                text: 'I\'ve ordered multiple kitchen items and each one has exceeded my expectations. The fruit basket is my favorite - functional and beautiful!',
                rating: 4
              }
            ].map((testimonial, index) => (
              <div 
                key={index}
                className="bg-gray-50 p-6 rounded-lg border border-gray-100 shadow-sm"
                data-aos="fade-up"
                data-aos-delay={index * 100}
              >
                <div className="flex items-center mb-4">
                  <img 
                    src={testimonial.avatar} 
                    alt={testimonial.name}
                    className="w-12 h-12 rounded-full object-cover mr-4 border-2 border-green-500"
                  />
                  <div>
                    <h4 className="font-semibold">{testimonial.name}</h4>
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <svg 
                          key={i}
                          className={`w-4 h-4 ${i < testimonial.rating ? 'text-amber-500' : 'text-gray-300'}`}
                          fill="currentColor"
                          viewBox="0 0 20 20"
                        >
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-600 italic">{testimonial.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Newsletter Section */}
      <section className="py-16 bg-gradient-to-r from-green-600 to-amber-600 text-white">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto text-center">
            <h2 
              className="text-3xl md:text-4xl font-bold mb-4" 
              data-aos="fade-up"
            >
              Stay Updated with Our Latest Products
            </h2>
            <p 
              className="text-lg mb-8 text-white/90" 
              data-aos="fade-up" 
              data-aos-delay="100"
            >
              Subscribe to our newsletter and be the first to know about new arrivals and special offers.
            </p>
            
            <form 
              className="flex flex-col sm:flex-row gap-4 max-w-xl mx-auto"
              data-aos="fade-up" 
              data-aos-delay="200"
            >
              <input 
                type="email" 
                placeholder="Enter your email" 
                className="flex-grow px-4 py-3 rounded-md text-gray-800 focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
              <button 
                type="submit" 
                className="bg-amber-600 hover:bg-amber-700 px-6 py-3 rounded-md font-medium transition-colors"
              >
                Subscribe
              </button>
            </form>
            
            <p 
              className="mt-4 text-sm text-white/80"
              data-aos="fade-up" 
              data-aos-delay="300"
            >
              By subscribing, you agree to receive marketing emails from us. Don't worry, we respect your privacy.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;