import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useCart } from '../contexts/CartContext';
import { useWishlist } from '../contexts/WishlistContext';
import ProductGrid from '../components/products/ProductGrid';
import { allProducts } from '../utils/data';
import { Heart, ShoppingCart, Share2, Minus, Plus, ArrowLeft, Check, Truck, Shield, Leaf } from 'lucide-react';

const ProductDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const productId = parseInt(id || '0');
  const product = allProducts.find(p => p.id === productId);
  
  const { addToCart } = useCart();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();
  
  const [quantity, setQuantity] = useState(1);
  const [inWishlist, setInWishlist] = useState(false);
  const [addedToCart, setAddedToCart] = useState(false);
  const [activeImage, setActiveImage] = useState(0);
  const [relatedProducts, setRelatedProducts] = useState([]);
  
  useEffect(() => {
    window.scrollTo(0, 0);
    if (product) {
      document.title = `${product.name} - B & C Products`;
      
      // Set related products (same category, excluding current product)
      const related = allProducts
        .filter(p => p.categorySlug === product.categorySlug && p.id !== product.id)
        .slice(0, 4);
      setRelatedProducts(related);
    }
  }, [product]);
  
  useEffect(() => {
    if (product) {
      setInWishlist(isInWishlist(product.id));
    }
  }, [product, isInWishlist]);
  
  if (!product) {
    return (
      <div className="container-custom py-16 text-center">
        <h2 className="text-2xl font-bold mb-4">Product Not Found</h2>
        <p className="mb-8">The product you are looking for does not exist.</p>
        <Link to="/products" className="btn-primary">
          Browse Products
        </Link>
      </div>
    );
  }
  
  const handleQuantityChange = (value: number) => {
    if (value >= 1 && value <= 10) {
      setQuantity(value);
    }
  };
  
  const handleAddToCart = () => {
    addToCart(product, quantity);
    setAddedToCart(true);
    setTimeout(() => setAddedToCart(false), 2000);
  };
  
  const handleWishlistToggle = () => {
    if (inWishlist) {
      removeFromWishlist(product.id);
      setInWishlist(false);
    } else {
      addToWishlist(product);
      setInWishlist(true);
    }
  };
  
  const images = [
    product.imageUrl,
    // Additional images would be here in a real app
    "https://images.pexels.com/photos/4210807/pexels-photo-4210807.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    "https://images.pexels.com/photos/4207788/pexels-photo-4207788.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
  ];
  
  return (
    <div className="bg-white">
      <div className="container-custom py-8">
        {/* Breadcrumbs */}
        <div className="flex items-center text-sm text-gray-500 mb-8">
          <Link to="/" className="hover:text-green-700">Home</Link>
          <span className="mx-2">/</span>
          <Link to="/products" className="hover:text-green-700">Products</Link>
          <span className="mx-2">/</span>
          <Link 
            to={`/products/${product.categorySlug}`} 
            className="hover:text-green-700"
          >
            {product.category}
          </Link>
          <span className="mx-2">/</span>
          <span className="text-gray-700">{product.name}</span>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 mb-16">
          {/* Product Images */}
          <div className="product-3d-container" data-aos="fade-right">
            <div className="product-3d">
              <div className="relative bg-gray-100 rounded-lg overflow-hidden">
                <img 
                  src={images[activeImage]} 
                  alt={product.name}
                  className="w-full h-auto object-cover aspect-square"
                />
              </div>
              
              <div className="grid grid-cols-3 gap-4 mt-4">
                {images.map((img, index) => (
                  <div 
                    key={index}
                    className={`cursor-pointer rounded-md overflow-hidden border-2 ${activeImage === index ? 'border-green-500' : 'border-transparent'}`}
                    onClick={() => setActiveImage(index)}
                  >
                    <img 
                      src={img} 
                      alt={`${product.name} view ${index + 1}`}
                      className="w-full h-24 object-cover"
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          {/* Product Info */}
          <div data-aos="fade-left">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">{product.name}</h1>
            
            <div className="flex items-center mb-4">
              <div className="flex text-amber-400">
                {[...Array(5)].map((_, i) => (
                  <svg 
                    key={i}
                    className="w-5 h-5"
                    fill={i < 4 ? 'currentColor' : 'none'}
                    stroke={i < 4 ? 'none' : 'currentColor'}
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
                  </svg>
                ))}
              </div>
              <span className="ml-2 text-gray-600">(24 reviews)</span>
            </div>
            
            <div className="text-2xl font-bold text-green-700 mb-6">₹{product.price.toLocaleString()}</div>
            
            <p className="text-gray-700 mb-6">
              {product.description || product.shortDescription}
            </p>
            
            {/* Product Feature Highlights */}
            <div className="mb-8">
              <h3 className="font-semibold mb-3">Features</h3>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <Check className="w-5 h-5 text-green-600 mr-2 mt-0.5" />
                  <span>100% natural bamboo and cane materials</span>
                </li>
                <li className="flex items-start">
                  <Check className="w-5 h-5 text-green-600 mr-2 mt-0.5" />
                  <span>Handcrafted by skilled artisans</span>
                </li>
                <li className="flex items-start">
                  <Check className="w-5 h-5 text-green-600 mr-2 mt-0.5" />
                  <span>Eco-friendly and sustainable</span>
                </li>
                <li className="flex items-start">
                  <Check className="w-5 h-5 text-green-600 mr-2 mt-0.5" />
                  <span>Durable and long-lasting with proper care</span>
                </li>
              </ul>
            </div>
            
            {/* Quantity Selector */}
            <div className="mb-6">
              <h3 className="font-semibold mb-3">Quantity</h3>
              <div className="flex items-center">
                <button 
                  onClick={() => handleQuantityChange(quantity - 1)}
                  className="px-3 py-1 border border-gray-300 rounded-l-md bg-gray-100 hover:bg-gray-200"
                  disabled={quantity <= 1}
                >
                  <Minus className="w-4 h-4" />
                </button>
                <input 
                  type="number"
                  min="1"
                  max="10"
                  value={quantity}
                  onChange={(e) => handleQuantityChange(parseInt(e.target.value))}
                  className="w-16 border-y border-gray-300 py-1 text-center focus:outline-none focus:ring-1 focus:ring-green-500"
                />
                <button 
                  onClick={() => handleQuantityChange(quantity + 1)}
                  className="px-3 py-1 border border-gray-300 rounded-r-md bg-gray-100 hover:bg-gray-200"
                  disabled={quantity >= 10}
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>
            
            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <button 
                onClick={handleAddToCart}
                className="btn-primary flex-1 py-3"
              >
                {addedToCart ? (
                  <>
                    <Check className="w-5 h-5 mr-2" />
                    Added to Cart
                  </>
                ) : (
                  <>
                    <ShoppingCart className="w-5 h-5 mr-2" />
                    Add to Cart
                  </>
                )}
              </button>
              
              <button 
                onClick={handleWishlistToggle}
                className={`flex items-center justify-center py-3 px-4 rounded-md border transition-colors ${
                  inWishlist 
                    ? 'border-red-500 text-red-500 hover:bg-red-50' 
                    : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                }`}
              >
                <Heart className={`w-5 h-5 ${inWishlist ? 'fill-current' : ''}`} />
              </button>
              
              <button className="flex items-center justify-center py-3 px-4 rounded-md border border-gray-300 text-gray-700 hover:bg-gray-50">
                <Share2 className="w-5 h-5" />
              </button>
            </div>
            
            {/* Info Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
              <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                <Truck className="w-5 h-5 text-green-600 mr-3" />
                <span className="text-sm">Free Shipping</span>
              </div>
              <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                <Shield className="w-5 h-5 text-green-600 mr-3" />
                <span className="text-sm">Quality Guarantee</span>
              </div>
              <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                <Leaf className="w-5 h-5 text-green-600 mr-3" />
                <span className="text-sm">Eco-Friendly</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Product Details Tabs */}
        <div className="mb-16">
          <div className="border-b border-gray-200">
            <div className="flex space-x-8">
              <button className="py-4 border-b-2 border-green-600 font-medium text-green-600">
                Description
              </button>
              <button className="py-4 text-gray-500 hover:text-gray-700">
                Specifications
              </button>
              <button className="py-4 text-gray-500 hover:text-gray-700">
                Reviews (24)
              </button>
            </div>
          </div>
          
          <div className="py-6">
            <p className="mb-4">
              {product.description || `Experience the natural beauty and eco-friendly elegance of our handcrafted ${product.name}. Made from premium quality bamboo and cane, this product combines traditional craftsmanship with modern design sensibilities.`}
            </p>
            <p className="mb-4">
              Each piece is carefully crafted by skilled artisans, ensuring attention to detail and superior quality. The natural materials create a warm, organic aesthetic that complements any home decor style.
            </p>
            <p>
              Our bamboo and cane products are not only beautiful but also sustainable and environmentally friendly. By choosing our products, you're making a conscious decision to support eco-friendly materials and traditional craftsmanship.
            </p>
          </div>
        </div>
        
        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div>
            <h2 className="text-2xl font-bold mb-8">You May Also Like</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {relatedProducts.map(relatedProduct => (
                <div key={relatedProduct.id} className="product-3d-container">
                  <div className="product-card product-3d">
                    <div className="product-card-img-container">
                      <Link to={`/product/${relatedProduct.id}`}>
                        <img 
                          src={relatedProduct.imageUrl} 
                          alt={relatedProduct.name} 
                          className="product-card-img"
                        />
                      </Link>
                    </div>
                    <div className="p-4">
                      <Link 
                        to={`/product/${relatedProduct.id}`}
                        className="text-lg font-semibold text-gray-800 hover:text-green-700 transition-colors"
                      >
                        {relatedProduct.name}
                      </Link>
                      <div className="text-amber-600 font-bold mt-2">₹{relatedProduct.price.toLocaleString()}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductDetailPage;