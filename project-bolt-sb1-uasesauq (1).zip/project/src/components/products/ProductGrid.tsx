import React from 'react';
import ProductCard from './ProductCard';
import { Product } from '../../utils/types';

interface ProductGridProps {
  products: Product[];
  title?: string;
  subtitle?: string;
}

const ProductGrid: React.FC<ProductGridProps> = ({ products, title, subtitle }) => {
  return (
    <div className="container-custom py-12">
      {title && (
        <div className="text-center mb-12">
          <h2 className="section-title" data-aos="fade-up">{title}</h2>
          {subtitle && <p className="section-subtitle" data-aos="fade-up" data-aos-delay="100">{subtitle}</p>}
        </div>
      )}
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {products.map((product, index) => (
          <ProductCard 
            key={product.id} 
            product={product} 
          />
        ))}
      </div>
    </div>
  );
};

export default ProductGrid;