import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart, ShoppingCart } from 'lucide-react';
import { Product } from '../../utils/types';
import { useCart } from '../../contexts/CartContext';
import { useWishlist } from '../../contexts/WishlistContext';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart } = useCart();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();
  const [isHovered, setIsHovered] = useState(false);
  const [animate, setAnimate] = useState<'heart' | 'cart' | null>(null);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product);
    setAnimate('cart');
    setTimeout(() => setAnimate(null), 1000);
  };

  const handleWishlistToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (isInWishlist(product.id)) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product);
      setAnimate('heart');
      setTimeout(() => setAnimate(null), 1500);
    }
  };

  return (
    <div 
      className="product-3d-container h-full" 
      data-aos="fade-up"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className={`product-card product-3d ${isHovered ? 'shadow-xl' : ''}`}>
        <div className="product-card-img-container">
          <Link to={`/product/${product.id}`}>
            <img 
              src={product.imageUrl} 
              alt={product.name} 
              className="product-card-img"
            />
          </Link>
          
          {/* Quick Action Buttons */}
          <div className={`absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/70 to-transparent flex justify-between items-center transition-opacity duration-300 ${isHovered ? 'opacity-100' : 'opacity-0'}`}>
            <button 
              onClick={handleWishlistToggle}
              className={`p-2 rounded-full ${isInWishlist(product.id) ? 'bg-red-500 text-white' : 'bg-white text-gray-700'} transition-colors`}
            >
              <Heart className={`w-5 h-5 ${animate === 'heart' ? 'heart-pulse' : ''}`} />
            </button>
            
            <button 
              onClick={handleAddToCart}
              className="bg-green-600 hover:bg-green-700 text-white px-3 py-1.5 rounded-full text-sm flex items-center transition-colors"
            >
              <ShoppingCart className={`w-4 h-4 mr-1.5 ${animate === 'cart' ? 'cart-wiggle' : ''}`} />
              Add to Cart
            </button>
          </div>
        </div>
        
        <div className="p-4 flex flex-col flex-grow">
          <span className="text-xs text-green-600 font-medium uppercase mb-1">{product.category}</span>
          <Link 
            to={`/product/${product.id}`}
            className="text-lg font-semibold text-gray-800 hover:text-green-700 transition-colors mb-1"
          >
            {product.name}
          </Link>
          <div className="text-amber-600 font-bold mt-1 mb-3">₹{product.price.toLocaleString()}</div>
          <p className="text-sm text-gray-600 mb-4 flex-grow">{product.shortDescription}</p>
          
          <Link 
            to={`/product/${product.id}`}
            className="text-green-700 hover:text-green-800 text-sm font-medium flex items-center mt-auto transition-colors"
          >
            View Details
            <svg className="w-3.5 h-3.5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path>
            </svg>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;