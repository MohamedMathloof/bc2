import React from 'react';
import { Link } from 'react-router-dom';
import { categories } from '../../utils/data';

const FeaturedCategories = () => {
  return (
    <section className="py-16 bg-white">
      <div className="container-custom">
        <div className="text-center mb-12">
          <h2 className="section-title" data-aos="fade-up">Shop by Category</h2>
          <p className="section-subtitle" data-aos="fade-up" data-aos-delay="100">
            Explore our range of handcrafted bamboo and cane products
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((category, index) => (
            <Link 
              key={category.id} 
              to={`/products/${category.slug}`}
              className="group relative overflow-hidden rounded-lg shadow-md h-64"
              data-aos="fade-up"
              data-aos-delay={index * 100}
            >
              <img 
                src={category.imageUrl} 
                alt={category.name}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/40 to-transparent"></div>
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <h3 className="text-xl font-bold text-white mb-1">{category.name}</h3>
                <p className="text-sm text-gray-200 mb-3">{category.description}</p>
                <span className="inline-flex items-center text-white text-sm font-medium group-hover:underline">
                  Shop Now
                  <svg className="w-4 h-4 ml-1 transition-transform duration-300 group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path>
                  </svg>
                </span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedCategories;