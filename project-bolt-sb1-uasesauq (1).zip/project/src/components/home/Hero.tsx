import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag, Leaf } from 'lucide-react';

const Hero = () => {
  return (
    <div className="relative overflow-hidden bg-gradient-to-r from-green-50 to-amber-50 py-16 md:py-24">
      <div className="container-custom relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Hero Text */}
          <div className="text-center lg:text-left">
            <h1 
              className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6" 
              data-aos="fade-right"
            >
              <span className="block">Handcrafted</span>
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-green-700 to-amber-600">
                Bamboo & Cane
              </span>
              <span className="block">Creations</span>
            </h1>
            
            <p 
              className="text-lg md:text-xl text-gray-700 mb-8 max-w-xl mx-auto lg:mx-0" 
              data-aos="fade-right" 
              data-aos-delay="100"
            >
              Discover our stunning collection of sustainable bamboo and cane products, 
              crafted with care to bring natural elegance to your home.
            </p>
            
            <div 
              className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4"
              data-aos="fade-up" 
              data-aos-delay="200"
            >
              <Link 
                to="/products" 
                className="btn-primary w-full sm:w-auto"
              >
                <ShoppingBag className="w-5 h-5 mr-2" />
                Shop Now
              </Link>
              
              <Link 
                to="/about" 
                className="btn-outline w-full sm:w-auto"
              >
                <Leaf className="w-5 h-5 mr-2" />
                Learn More
              </Link>
            </div>
            
            <div 
              className="mt-8 flex items-center justify-center lg:justify-start gap-6"
              data-aos="fade-up" 
              data-aos-delay="300"
            >
              <div className="flex -space-x-2">
                {[1, 2, 3, 4].map((i) => (
                  <div key={i} className="w-8 h-8 rounded-full border-2 border-white overflow-hidden">
                    <img 
                      src={`https://i.pravatar.cc/100?img=${i + 10}`} 
                      alt="Customer" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                ))}
              </div>
              <div className="text-sm text-gray-600">
                <span className="font-semibold text-gray-900">300+</span> Happy Customers
              </div>
            </div>
          </div>
          
          {/* Hero Image */}
          <div 
            className="relative product-3d-container"
            data-aos="fade-left" 
            data-aos-delay="200"
          >
            <div className="product-3d relative">
              <img 
                src="https://images.pexels.com/photos/3932929/pexels-photo-3932929.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="Bamboo furniture" 
                className="w-full rounded-xl shadow-2xl z-10 relative"
              />
              <div className="absolute w-full h-full bg-gray-900/20 top-0 left-0 rounded-xl"></div>
              
              {/* Floating features */}
              <div className="absolute top-6 left-6 bg-white/90 backdrop-blur-sm rounded-lg p-4 shadow-lg max-w-[180px] floating" style={{ animationDelay: '0.2s' }}>
                <span className="text-xs font-medium text-green-600">QUALITY MATERIALS</span>
                <h3 className="font-semibold">100% Natural Bamboo</h3>
              </div>
              
              <div className="absolute bottom-6 right-6 bg-white/90 backdrop-blur-sm rounded-lg p-4 shadow-lg max-w-[180px] floating" style={{ animationDelay: '0.5s' }}>
                <span className="text-xs font-medium text-amber-600">ECO FRIENDLY</span>
                <h3 className="font-semibold">Sustainable Sourcing</h3>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Background decorative elements */}
      <div className="absolute top-1/4 right-0 w-64 h-64 bg-green-200 rounded-full filter blur-3xl opacity-30"></div>
      <div className="absolute bottom-1/4 left-0 w-80 h-80 bg-amber-200 rounded-full filter blur-3xl opacity-30"></div>
    </div>
  );
};

export default Hero;