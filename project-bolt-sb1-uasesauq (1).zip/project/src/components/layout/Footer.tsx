import React from 'react';
import { Link } from 'react-router-dom';
import { PhoneCall, Mail, MapPin, MessageSquare, Instagram, Facebook, Twitter } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="container-custom py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* About Column */}
          <div data-aos="fade-up" data-aos-delay="100">
            <h3 className="text-xl font-bold text-white mb-4">B & C Products</h3>
            <p className="mb-4 text-gray-400 leading-relaxed">
              We specialize in sustainable bamboo and cane products that combine traditional craftsmanship with modern design. Our eco-friendly products bring natural beauty to your home.
            </p>
            <div className="flex space-x-4 mt-6">
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
            </div>
          </div>
          
          {/* Products Column */}
          <div data-aos="fade-up" data-aos-delay="200">
            <h3 className="text-xl font-bold text-white mb-4">Products</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/products/furniture" className="text-gray-400 hover:text-white transition-colors">Furniture</Link>
              </li>
              <li>
                <Link to="/products/miniatures" className="text-gray-400 hover:text-white transition-colors">Miniatures</Link>
              </li>
              <li>
                <Link to="/products/kitchen" className="text-gray-400 hover:text-white transition-colors">Kitchen Items</Link>
              </li>
              <li>
                <Link to="/products/baby-products" className="text-gray-400 hover:text-white transition-colors">Baby Products</Link>
              </li>
            </ul>
          </div>
          
          {/* Quick Links Column */}
          <div data-aos="fade-up" data-aos-delay="300">
            <h3 className="text-xl font-bold text-white mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/about" className="text-gray-400 hover:text-white transition-colors">About Us</Link>
              </li>
              <li>
                <Link to="/profile" className="text-gray-400 hover:text-white transition-colors">My Account</Link>
              </li>
              <li>
                <Link to="/cart" className="text-gray-400 hover:text-white transition-colors">Shopping Cart</Link>
              </li>
              <li>
                <Link to="/privacy-policy" className="text-gray-400 hover:text-white transition-colors">Privacy Policy</Link>
              </li>
            </ul>
          </div>
          
          {/* Contact Column */}
          <div data-aos="fade-up" data-aos-delay="400">
            <h3 className="text-xl font-bold text-white mb-4">Contact Us</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <PhoneCall className="w-5 h-5 text-green-500 mr-3 mt-0.5" />
                <div>
                  <p className="text-gray-400">Call or WhatsApp</p>
                  <a href="tel:+919566315769" className="text-white hover:text-green-400 transition-colors">+91 9566315769</a>
                </div>
              </li>
              <li className="flex items-start">
                <Mail className="w-5 h-5 text-green-500 mr-3 mt-0.5" />
                <div>
                  <p className="text-gray-400">Email Us</p>
                  <a href="mailto:mohamedmathloof8@gmail.com" className="text-white hover:text-green-400 transition-colors">mohamedmathloof8@gmail.com</a>
                </div>
              </li>
              <li className="flex items-start">
                <MapPin className="w-5 h-5 text-green-500 mr-3 mt-0.5" />
                <div>
                  <p className="text-gray-400">Location</p>
                  <p className="text-white">Tamil Nadu, India</p>
                </div>
              </li>
            </ul>
          </div>
        </div>
        
        {/* Bottom Bar */}
        <div className="border-t border-gray-800 mt-12 pt-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-gray-500">
              &copy; {new Date().getFullYear()} B & C Products. All rights reserved.
            </p>
            <div className="mt-4 md:mt-0">
              <a 
                href="https://wa.me/919566315769" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 rounded-md text-white transition-colors"
              >
                <MessageSquare className="w-4 h-4 mr-2" />
                Chat on WhatsApp
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;