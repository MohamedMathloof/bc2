import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Order } from '../utils/types';

interface UserContextType {
  user: User | null;
  orders: Order[];
  login: (email: string, password: string) => Promise<void>;
  register: (userData: Partial<User>) => Promise<void>;
  logout: () => void;
  updateUserProfile: (userData: Partial<User>) => Promise<void>;
  isLoggedIn: boolean;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const useUser = () => {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};

export const UserProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    const savedUser = localStorage.getItem('user');
    return savedUser ? JSON.parse(savedUser) : null;
  });
  
  const [orders, setOrders] = useState<Order[]>(() => {
    const savedOrders = localStorage.getItem('orders');
    return savedOrders ? JSON.parse(savedOrders) : [];
  });

  useEffect(() => {
    if (user) {
      localStorage.setItem('user', JSON.stringify(user));
    } else {
      localStorage.removeItem('user');
    }
  }, [user]);

  useEffect(() => {
    localStorage.setItem('orders', JSON.stringify(orders));
  }, [orders]);

  const login = async (email: string, password: string) => {
    // Mock login - in a real app, this would call an API
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Check against mock user data
      if (email === 'user@example.com' && password === 'password') {
        const userData: User = {
          id: 1,
          name: 'Test User',
          email: 'user@example.com',
          phone: '9876543210',
          address: {
            street: '123 Main St',
            city: 'Bangalore',
            state: 'Karnataka',
            zipCode: '560001',
            country: 'India'
          }
        };
        setUser(userData);
        return;
      }
      
      throw new Error('Invalid email or password');
    } catch (error) {
      throw error;
    }
  };

  const register = async (userData: Partial<User>) => {
    // Mock registration - in a real app, this would call an API
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const newUser: User = {
        id: Math.floor(Math.random() * 1000) + 1,
        name: userData.name || 'User',
        email: userData.email || 'user@example.com',
        phone: userData.phone || '',
        address: userData.address || {
          street: '',
          city: '',
          state: '',
          zipCode: '',
          country: 'India'
        }
      };
      
      setUser(newUser);
    } catch (error) {
      throw error;
    }
  };

  const logout = () => {
    setUser(null);
  };

  const updateUserProfile = async (userData: Partial<User>) => {
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      if (user) {
        const updatedUser = { ...user, ...userData };
        setUser(updatedUser);
      }
    } catch (error) {
      throw error;
    }
  };

  return (
    <UserContext.Provider value={{
      user,
      orders,
      login,
      register,
      logout,
      updateUserProfile,
      isLoggedIn: user !== null
    }}>
      {children}
    </UserContext.Provider>
  );
};